import React from 'react';
import { Calendar } from 'lucide-react';
import { useGoogleLogin } from '@react-oauth/google';

interface GoogleAuthButtonProps {
  onSuccess: (token: string) => void;
}

export function GoogleAuthButton({ onSuccess }: GoogleAuthButtonProps) {
  const login = useGoogleLogin({
    onSuccess: (response) => onSuccess(response.access_token),
    scope: 'https://www.googleapis.com/auth/calendar.events',
    flow: 'implicit',
    ux_mode: 'popup',
  });

  return (
    <button
      onClick={() => login()}
      className="flex items-center justify-center gap-2 w-full bg-white text-gray-600 border border-gray-300 rounded-lg px-4 py-2 hover:bg-gray-50 transition-colors"
    >
      <Calendar className="h-5 w-5" />
      Connect Google Calendar
    </button>
  );
}