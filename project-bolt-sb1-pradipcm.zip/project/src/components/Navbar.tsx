import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Calendar, Settings } from 'lucide-react';

export function Navbar() {
  const location = useLocation();
  
  const isActive = (path: string) => 
    location.pathname === path ? "text-blue-600" : "text-gray-600 hover:text-blue-600";

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Calendar className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">Schedule Reader</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link to="/" className={`${isActive('/')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>
              Home
            </Link>
            <Link to="/about" className={`${isActive('/about')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>
              About
            </Link>
            <Link to="/contact" className={`${isActive('/contact')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>
              Contact
            </Link>
            <Link to="/settings" className="text-gray-600 hover:text-blue-600 p-2 rounded-full transition-colors">
              <Settings className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}