import React from 'react';
import { Calendar, Clock, Upload, CalendarCheck } from 'lucide-react';

export function About() {
  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">About Schedule Reader</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          We're simplifying schedule management for busy professionals with smart technology 
          and seamless calendar integration.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
          <p className="text-gray-600">
            Schedule Reader was born from a simple idea: make managing work schedules easier. 
            We understand the challenges of keeping track of shifting schedules, and we're here 
            to help you stay organized with minimal effort.
          </p>
        </div>
        <div>
          <img 
            src="https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&q=80&w=800"
            alt="Person working at desk with calendar"
            className="rounded-lg shadow-md w-full h-64 object-cover"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-16">
        <div className="text-center p-6">
          <Upload className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Upload Schedule</h3>
          <p className="text-gray-600">Simply upload your schedule image</p>
        </div>
        <div className="text-center p-6">
          <Clock className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Smart Processing</h3>
          <p className="text-gray-600">Our AI extracts schedule details</p>
        </div>
        <div className="text-center p-6">
          <Calendar className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Auto Sync</h3>
          <p className="text-gray-600">Seamless Google Calendar integration</p>
        </div>
        <div className="text-center p-6">
          <CalendarCheck className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Stay Organized</h3>
          <p className="text-gray-600">Never miss a shift again</p>
        </div>
      </div>
    </div>
  );
}