import React from 'react';
import { Bell, Calendar, Clock, Shield } from 'lucide-react';

export function Settings() {
  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Settings</h1>

        <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Calendar className="h-6 w-6 text-blue-600" />
                <h2 className="ml-3 text-lg font-medium text-gray-900">Calendar Settings</h2>
              </div>
              <button className="text-sm text-blue-600 hover:text-blue-800">
                Manage
              </button>
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Configure your Google Calendar integration preferences
            </p>
          </div>

          <div className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Bell className="h-6 w-6 text-blue-600" />
                <h2 className="ml-3 text-lg font-medium text-gray-900">Notifications</h2>
              </div>
              <button className="text-sm text-blue-600 hover:text-blue-800">
                Configure
              </button>
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Manage your notification preferences and alerts
            </p>
          </div>

          <div className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Clock className="h-6 w-6 text-blue-600" />
                <h2 className="ml-3 text-lg font-medium text-gray-900">Time Zone</h2>
              </div>
              <select className="text-sm text-gray-700 border rounded-md p-1">
                <option>Eastern Time (ET)</option>
                <option>Pacific Time (PT)</option>
                <option>Central Time (CT)</option>
                <option>Mountain Time (MT)</option>
              </select>
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Set your preferred time zone for schedule display
            </p>
          </div>

          <div className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Shield className="h-6 w-6 text-blue-600" />
                <h2 className="ml-3 text-lg font-medium text-gray-900">Privacy</h2>
              </div>
              <button className="text-sm text-blue-600 hover:text-blue-800">
                Review
              </button>
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Review and update your privacy settings
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}