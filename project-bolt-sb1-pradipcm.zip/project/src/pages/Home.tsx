import React, { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { ImageUploader } from '../components/ImageUploader';
import { GoogleAuthButton } from '../components/GoogleAuthButton';
import { processImage } from '../utils/ocr';
import type { ProcessedSchedule } from '../types';

export function Home() {
  const [loading, setLoading] = useState(false);
  const [processedData, setProcessedData] = useState<ProcessedSchedule | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);

  const handleImageUpload = async (file: File) => {
    setLoading(true);
    try {
      const text = await processImage(file);
      setProcessedData({ events: [], rawText: text });
    } catch (error) {
      console.error('Error processing image:', error);
      alert('Failed to process the image. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Transform Your Schedule Management
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Upload your work schedule image and we'll automatically add it to your Google Calendar. 
          Save time and never miss a shift again.
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-8">
        {!accessToken ? (
          <div className="py-8">
            <p className="text-center text-gray-600 mb-4">
              First, connect your Google Calendar to continue
            </p>
            <div className="max-w-sm mx-auto">
              <GoogleAuthButton onSuccess={setAccessToken} />
            </div>
          </div>
        ) : loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
            <span className="ml-2 text-gray-600">Processing image...</span>
          </div>
        ) : (
          <ImageUploader onImageUpload={handleImageUpload} />
        )}

        {processedData && (
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <h2 className="text-lg font-semibold mb-2">Extracted Text:</h2>
            <pre className="whitespace-pre-wrap text-sm text-gray-700">
              {processedData.rawText}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}