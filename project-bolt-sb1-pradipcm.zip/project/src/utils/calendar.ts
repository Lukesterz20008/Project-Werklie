import type { ScheduleEvent } from '../types';

const CALENDAR_API_BASE = 'https://www.googleapis.com/calendar/v3';

export async function addToGoogleCalendar(event: ScheduleEvent, accessToken: string) {
  try {
    const response = await fetch(`${CALENDAR_API_BASE}/calendars/primary/events`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        summary: 'Work Shift',
        description: event.description,
        start: {
          dateTime: `${event.date}T${event.startTime}:00`,
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        },
        end: {
          dateTime: `${event.date}T${event.endTime}:00`,
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        },
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to add event to calendar');
    }

    return await response.json();
  } catch (error) {
    console.error('Error adding event to calendar:', error);
    throw error;
  }
}