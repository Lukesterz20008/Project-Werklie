import { createWorker } from 'tesseract.js';

export async function processImage(imageFile: File): Promise<string> {
  const worker = await createWorker('eng');
  
  try {
    const { data: { text } } = await worker.recognize(imageFile);
    await worker.terminate();
    return text;
  } catch (error) {
    console.error('OCR Error:', error);
    await worker.terminate();
    throw new Error('Failed to process image');
  }
}