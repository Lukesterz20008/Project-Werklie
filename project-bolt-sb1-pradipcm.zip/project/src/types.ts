export interface ScheduleEvent {
  date: string;
  startTime: string;
  endTime: string;
  description?: string;
}

export interface ProcessedSchedule {
  events: ScheduleEvent[];
  rawText: string;
}